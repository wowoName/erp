# dyt-erp

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

## 后端技术栈

```
spring boot mybatis  shiro  mysql
```

### 体验地址

[体验地址](http://101.200.188.171:8888/#/login)

## 联系方式

```
1069722589@qq.com
```

##

!\_-
